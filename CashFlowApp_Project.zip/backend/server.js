const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Conexión a MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.log(err));

// Esquema de la base de datos
const transactionSchema = new mongoose.Schema({
  type: String, // 'ingreso' o 'gasto'
  amount: Number,
  date: { type: Date, default: Date.now },
  status: { type: String, default: 'Pendiente' },
  location: String, // Sucursal
  approvedBy: String, // Encargado/Admin
});

const Transaction = mongoose.model('Transaction', transactionSchema);

// Rutas API
app.post('/api/transaction', async (req, res) => {
  const { type, amount, location } = req.body;

  const newTransaction = new Transaction({
    type,
    amount,
    location,
  });

  try {
    const savedTransaction = await newTransaction.save();
    res.status(201).json(savedTransaction);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

app.get('/api/transactions', async (req, res) => {
  try {
    const transactions = await Transaction.find();
    res.status(200).json(transactions);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Iniciar servidor
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
