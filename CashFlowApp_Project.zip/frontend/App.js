import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList } from 'react-native';
import axios from 'axios';

export default function App() {
  const [amount, setAmount] = useState('');
  const [location, setLocation] = useState('');
  const [transactions, setTransactions] = useState([]);

  const addTransaction = async () => {
    if (amount && location) {
      const response = await axios.post('http://your_server_address/api/transaction', {
        type: 'ingreso', // o 'gasto'
        amount: parseFloat(amount),
        location,
      });
      setTransactions([...transactions, response.data]);
      setAmount('');
      setLocation('');
    }
  };

  const fetchTransactions = async () => {
    const response = await axios.get('http://your_server_address/api/transactions');
    setTransactions(response.data);
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput
        placeholder="Cantidad"
        value={amount}
        onChangeText={setAmount}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Sucursal"
        value={location}
        onChangeText={setLocation}
      />
      <Button title="Agregar Ingreso" onPress={addTransaction} />
      <Button title="Ver Transacciones" onPress={fetchTransactions} />

      <FlatList
        data={transactions}
        keyExtractor={(item) => item._id}
        renderItem={({ item }) => (
          <View>
            <Text>{`Monto: ${item.amount} | Sucursal: ${item.location} | Estado: ${item.status}`}</Text>
          </View>
        )}
      />
    </View>
  );
}
